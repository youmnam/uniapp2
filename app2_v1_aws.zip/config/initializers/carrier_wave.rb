
require 'carrierwave/orm/activerecord'