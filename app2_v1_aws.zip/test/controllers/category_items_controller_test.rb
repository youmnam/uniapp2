require 'test_helper'

class CategoryItemsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
