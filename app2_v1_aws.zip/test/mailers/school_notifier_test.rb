require 'test_helper'

class SchoolNotifierTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
