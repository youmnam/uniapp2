# Preview all emails at http://localhost:3000/rails/mailers/school_notifier
class SchoolNotifierPreview < ActionMailer::Preview

end
