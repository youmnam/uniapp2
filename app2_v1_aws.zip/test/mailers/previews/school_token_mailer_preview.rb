# Preview all emails at http://localhost:3000/rails/mailers/school_token_mailer
class SchoolTokenMailerPreview < ActionMailer::Preview

end
