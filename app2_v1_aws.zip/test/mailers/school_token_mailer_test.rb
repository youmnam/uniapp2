require 'test_helper'

class SchoolTokenMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
