require 'test_helper'

class UserRateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
