require 'test_helper'

class CategoryFilterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
