require 'test_helper'

class RentpTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
