require 'test_helper'

class ReservedItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
