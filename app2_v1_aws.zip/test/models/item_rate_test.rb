require 'test_helper'

class ItemRateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
