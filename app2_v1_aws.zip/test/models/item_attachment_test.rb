require 'test_helper'

class ItemAttachmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
