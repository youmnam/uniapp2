require 'test_helper'

class CarCatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
