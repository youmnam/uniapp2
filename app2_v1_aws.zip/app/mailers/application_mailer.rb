class ApplicationMailer < ActionMailer::Base
  default from: "magdy.youmna@gmail.com"
  
  layout 'mailer'
end
