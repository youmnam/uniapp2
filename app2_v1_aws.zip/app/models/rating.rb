class Rating < ActiveRecord::Base
  belongs_to :school
  
  def getTotalRating
  
 
  end 
end
