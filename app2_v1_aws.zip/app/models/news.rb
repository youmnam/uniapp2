class News < ApplicationRecord
belongs_to :school
end
