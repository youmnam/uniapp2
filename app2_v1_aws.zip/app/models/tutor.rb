class Tutor < ActiveRecord::Base
end
